﻿/// <reference path="jquery-2.0.3.js" />
/// <reference path="modernizr-2.8.3.js" />
/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="respond.js" />

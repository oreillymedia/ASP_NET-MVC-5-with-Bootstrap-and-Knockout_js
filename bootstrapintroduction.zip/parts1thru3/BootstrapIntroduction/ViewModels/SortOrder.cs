﻿namespace BootstrapIntroduction.ViewModels
{
    public enum SortOrder
    {
        ASC,
        DESC
    }
}
